@extends('layouts.master')

@section('content')

    Pantalla principal

@endsection