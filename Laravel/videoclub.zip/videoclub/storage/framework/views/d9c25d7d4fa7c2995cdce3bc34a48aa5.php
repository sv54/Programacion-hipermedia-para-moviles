<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col-sm-4">
            <img src="<?php echo e($pelicula->poster); ?>" alt="Portada de la película">

        </div>
        <div class="col-sm-8">

            <h2><?php echo e($pelicula->title); ?></h2>
            <h5>Año: <?php echo e($pelicula->year); ?></h5>
            <h5>Director: <?php echo e($pelicula->director); ?></h5>
            <p><b>Resumen: </b> <?php echo e($pelicula->synopsis); ?></p>
            <p><b>Estado: </b>
                <?php if($pelicula->rented): ?>
                    Película actualmente alquilada
                    <br>
                    <a href="" class="btn btn-danger">Devolver Pelicula</a>
                <?php else: ?>
                    Película disponible para alquilar
                    <br>
                    <a href="" class="btn btn-primary d-inline-block">Alquilar Pelicula</a>
                <?php endif; ?>
            </p>

            
            <a href=<?php echo e("/catalog/edit/".$pelicula->id); ?> class="btn btn-warning d-inline-block">Editar Pelicula</a>
            <a href="/catalog" class="btn btn-default d-inline-block">Volver al Listado</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Serg2\source\repos\Master\Programacion-hipermedia-para-moviles\Laravel\videoclub\resources\views/catalog/show.blade.php ENDPATH**/ ?>